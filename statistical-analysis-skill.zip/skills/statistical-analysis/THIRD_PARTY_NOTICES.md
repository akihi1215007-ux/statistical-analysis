# Third-party notices

## Scientific Agent Skills — K-Dense Inc.

This skill includes modified material from `statistical-analysis` in
[K-Dense-AI/scientific-agent-skills](https://github.com/K-Dense-AI/scientific-agent-skills).

- Upstream revision: `a1043ef544e3a100c28e70a736b6cf32554d0677`.
- [Pinned skill source](https://github.com/K-Dense-AI/scientific-agent-skills/tree/a1043ef544e3a100c28e70a736b6cf32554d0677/skills/statistical-analysis).
- [Pinned upstream license](https://github.com/K-Dense-AI/scientific-agent-skills/blob/a1043ef544e3a100c28e70a736b6cf32554d0677/LICENSE.md).
- Copyright (c) 2025 K-Dense Inc.
- License: MIT; the full original terms are included in [LICENSE](LICENSE).

Derived material includes the skill entry point, statistical reference guides,
and `scripts/assumption_checks.py`. The adaptation has a shorter Chinese entry
point, study-design and validation guidance, revised statistical interpretation,
input validation and regression tests. The portable packaging removes
machine-specific paths and adds dependency declarations and installation guidance;
it does not change the seven diagnostic helper interfaces or their implementations.

The upstream revision identifies the reference source, not a claim that these
modified files are byte-identical to upstream. This is an independent adaptation,
not an official K-Dense product. Keep this notice and LICENSE with redistributed
copies, including when installing only the skill directory.

## External references and optional dependencies

Links to SciPy, statsmodels, NIST, APA, PyMC, ArviZ and Pingouin refer to external
documentation; their services and packages are not bundled or relicensed here.
Optional companion skills are named for interoperability and are not included.
