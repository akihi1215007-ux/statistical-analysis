---
name: statistical-analysis
description: Use when planning a research study or analysis, choosing comparisons and sample sizes, analyzing experimental or observational data, checking model assumptions, quantifying uncertainty, or validating statistical results. Also applies to validation plans for theoretical and deterministic simulation work.
license: MIT license
metadata:
  version: "2.2-portable"
  last-reviewed: "2026-11-03"
  skill-author: K-Dense Inc.
---

# 研究设计与结果验证

同一主技能负责事前设计和事后验证；已有方案先核对本次变化，局部问题直接回答。下表参考仅在需要展开方案、选择方法或运行诊断时读取。
方法由研究问题、待估量、采样单位和依赖关系决定。可选配套技能：计算代码使用 scientific-toolkit-skill；图件制作使用 scientific-visualization；正文组织使用 research-writing-skill。仅在已安装且适用时调用；未安装时使用当前可用工具，不自动安装或强制跳转。

## 按任务进入

| 当前任务 | 做什么 | 按需读取 |
| --- | --- | --- |
| 确定怎么研究、怎么比较、采多少样本 | 用已有信息给出可执行方案和判据；补问会改变设计的信息 | [设计方案](references/design_plan.md) |
| 已有数据，需要选择分析方法 | 先核对单位、配对/层级、指标、缺失和既定对比 | [方法选择](references/test_selection_guide.md) |
| 已有结果，需要检查是否可信 | 核对方案与实际执行，检查诊断、区间、敏感性和适用边界 | [诊断](references/assumptions_and_diagnostics.md) |
| 样本量、精度、效应量或可检测效应 | 写明目标效应/精度、方差、设计和资源约束 | [效应与功效](references/effect_sizes_and_power.md) |
| 明确需要贝叶斯估计或模型比较 | 明确似然、先验、目标与诊断，再选现有实现 | [贝叶斯](references/bayesian_statistics.md) |
| 整理统计结果或核对论文数字 | 依据实际输出给出完整但适量的报告 | [结果报告](references/reporting_standards.md) |

纯理论或确定性仿真：记录假设、约束、单位、误差容限、解析/基准对照与收敛验证。
没有采样不确定性就不硬套显著性检验或功效计算；需要传播参数不确定性时再定义随机模型。

## 事前设计

- 复用文献环节的研究问题和现有项目记录，明确要估计/预测/解释什么、用什么证据判断。
- 区分分配单位、独立观测单位和重复测量。受试者、设备、录音切出的时窗不自动成为独立样本。
- 沿用已定指标、对比、方法、采样/划分和验证判据，只补当前缺项或修订受变化影响的决定。
- 随机化、盲法、停止规则、缺失/排除和多重比较只在适用时细化；标明未定事项与影响。
- 确认性方案在看结果前确定；已经看过结果的调整如实标为探索或方案变更。
- 小问题可直接在对话中交付；持续项目更新原有事实清单，不强制新建报告或填写整张表。

## 事后验证

- 核对数据来源、实际样本量、单位、配对/层级、缺失处理及执行与预案的差异。
- 结合设计和图形检查相关诊断；Shapiro/Levene 非显著不证明假设成立，不能据阈值机械换检验。
- 结果包含目标效应及不确定性；p 值不代表效应大小、实际价值或因果识别。
- 用与采样单位相符的区间/重采样和相关结构模型；预测任务检查划分、调参泄漏与外推边界。
- 按科学问题做必要的敏感性、稳健性或物理/数值验算；保留负结果、失败条件和未解决问题。
- 区分未运行方案、已运行输出与已核验结论；复用计算环节的同版输入和结果，只重验受数据、方法或主张变化影响的部分，再交制图/写作。

## 计算与诊断工具

纯设计不导入计算栈。需要计算时先使用项目现有环境，默认选择已装 SciPy/statsmodels；Pingouin、PyMC/ArviZ 仅在任务需要时使用，不自动安装或锁死版本。
使用当前项目的 Python 解释器；数值辅助脚本依赖见 [requirements.txt](requirements.txt)，默认作图另需 [requirements-plot.txt](requirements-plot.txt)。纯设计无需安装这些依赖。
记录实际版本；遇到 API 差异先检查已装库的签名/文档，再按需核对官方文档。

把本技能的 `scripts/` 加入 `sys.path` 或 `PYTHONPATH` 后可导入：

```python
from assumption_checks import comprehensive_assumption_check
diagnostics = comprehensive_assumption_check(df, "score", "group", plot=False)
```

[assumption_checks.py](scripts/assumption_checks.py) 保留七个公开函数及默认 `plot=True`：
`check_normality`、`check_normality_per_group`、`check_homogeneity_of_variance`、
`check_linearity`、`detect_outliers`、`check_regression_diagnostics`、`comprehensive_assumption_check`。
`plot=False` 不加载 `matplotlib.pyplot`；作图时才需要绘图库。
分组输出为 `outliers_per_group`；配对诊断用对齐后的差值；OLS 用专门回归诊断。
旧字段 `is_normal`/`is_homogeneous` 和表列 `Normal` 仅表示未拒绝；辅助脚本不验证独立性，也不自动选方法。

## 实用边界

- 独立均值比较通常预先选 Welch；配对比较检查差值；聚类/重复测量显式建模依赖。
- 秩检验回答分布/秩问题，不能自动解释为中位数检验；转换、截尾和删除样本须有理由。
- 非显著不等于无效；如要支持“差异足够小”，预定有意义界值并采用等效性等适当方法。
- 多重比较事先定义检验族；缺失机制和排除规则透明记录；不尝试多个方案直到显著。
- 不默认 APA、贝叶斯、MCMC、完整诊断图集或全套报告；按任务和目标期刊选择。
