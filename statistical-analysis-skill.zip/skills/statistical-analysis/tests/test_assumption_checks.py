"""Behavioral regressions for diagnostics; run with unittest discovery."""

import contextlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import unittest
from unittest import mock
import warnings

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import assumption_checks as checks


class DiagnosticTests(unittest.TestCase):
    def test_all_numeric_helpers_work_without_importing_pyplot(self):
        # A global or plot=False-path pyplot import would break headless use.
        program = """
import contextlib, io, json, sys
import numpy as np
import pandas as pd
from statsmodels.regression.linear_model import OLS
from statsmodels.tools.tools import add_constant
import assumption_checks as c
rng = np.random.default_rng(7)
df = pd.DataFrame({'value': rng.normal(size=40), 'group': ['A']*20 + ['B']*20})
c.check_normality(df.value, plot=False)
c.check_normality_per_group(df, 'value', 'group', plot=False)
c.check_homogeneity_of_variance(df, 'value', 'group', plot=False)
c.check_linearity(np.arange(40), df.value, plot=False)
c.detect_outliers(df.value, plot=False)
model = OLS(df.value, add_constant(np.arange(40))).fit()
c.check_regression_diagnostics(model, plot=False)
with contextlib.redirect_stdout(io.StringIO()):
    c.comprehensive_assumption_check(df, 'value', 'group', plot=False)
print(json.dumps({'pyplot_loaded': 'matplotlib.pyplot' in sys.modules}))
"""
        env = dict(os.environ, PYTHONPATH=str(ROOT / "scripts"))
        result = subprocess.run(
            [sys.executable, "-B", "-c", program], cwd=ROOT, env=env,
            capture_output=True, text=True, check=True,
        )
        self.assertFalse(json.loads(result.stdout)["pyplot_loaded"])

    def test_nan_omissions_and_original_outlier_labels(self):
        values = pd.Series([0, np.nan, 0, 0, 0, 20], index=list("abcdef"))
        result = checks.detect_outliers(values, plot=False)
        self.assertEqual(result["n"], 5)
        self.assertEqual(result["n_missing"], 1)
        np.testing.assert_array_equal(result["outlier_indices"], [5])
        np.testing.assert_array_equal(result["outlier_labels"], ["f"])

    def test_plotting_remains_available_on_explicit_request(self):
        program = """
import numpy as np
import pandas as pd
from statsmodels.regression.linear_model import OLS
from statsmodels.tools.tools import add_constant
import assumption_checks as c
rng = np.random.default_rng(8)
df = pd.DataFrame({'v': rng.normal(size=40), 'g': ['A']*20 + ['B']*20})
c.check_normality(df.v)
c.check_normality_per_group(df, 'v', 'g')
c.check_homogeneity_of_variance(df, 'v', 'g')
c.check_linearity(np.arange(40), df.v)
c.detect_outliers(df.v)
c.check_regression_diagnostics(OLS(df.v, add_constant(np.arange(40))).fit())
import matplotlib.pyplot as plt
assert not plt.get_fignums(), 'diagnostic figures were not closed'
"""
        env = dict(os.environ, PYTHONPATH=str(ROOT / "scripts"), MPLBACKEND="Agg")
        result = subprocess.run(
            [sys.executable, "-B", "-c", program], cwd=ROOT, env=env,
            capture_output=True, text=True,
        )
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_invalid_numeric_inputs_are_rejected(self):
        for values in (
            [1, 2, np.inf], [1, 2], [2, 2, 2], [[1, 2, 3]],
            [1, 2, 3j], np.ma.array([1, 2, 3], mask=[False, True, False]),
        ):
            with self.subTest(values=values), self.assertRaises(ValueError):
                checks.check_normality(values, plot=False)
        for alpha in (0, 1, np.nan):
            with self.subTest(alpha=alpha), self.assertRaises(ValueError):
                checks.check_normality([1, 2, 4], alpha=alpha, plot=False)

    def test_large_normality_screen_has_no_binary_verdict(self):
        values = np.random.default_rng(4).normal(size=5001)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", UserWarning)
            result = checks.check_normality(values, plot=False)
        self.assertIsNone(result["normality_not_rejected"])
        self.assertFalse(result["p_value_reliable"])

    def test_missing_group_and_undefined_variance_screen_are_rejected(self):
        missing = pd.DataFrame({"v": [1, 2, 3], "g": ["A", None, "A"]})
        with self.assertRaises(ValueError):
            checks.check_normality_per_group(missing, "v", "g", plot=False)
        degenerate = pd.DataFrame({"v": [1, 1, 1, 2, 2, 2], "g": list("AAABBB")})
        with self.assertRaises(ValueError):
            checks.check_homogeneity_of_variance(degenerate, "v", "g", plot=False)

    def test_pairwise_nan_filtering_preserves_alignment(self):
        result = checks.check_linearity(
            [1, 2, np.nan, 4, 5], [3, np.nan, 90, 9, 11], plot=False,
        )
        self.assertEqual(result["n"], 3)
        self.assertEqual(result["n_missing"], 2)
        self.assertAlmostEqual(result["r_squared"], 1.0)
        with self.assertRaises(ValueError):
            checks.check_linearity([1, 2, 3], [1, 2], plot=False)

    def test_grouped_outliers_are_not_pooled(self):
        data = pd.DataFrame({"v": [0, 1, 2, 100, 101, 102], "g": list("AAABBB")})
        with contextlib.redirect_stdout(io.StringIO()):
            result = checks.comprehensive_assumption_check(data, "v", "g", plot=False)
        self.assertEqual(set(result["outliers_per_group"]), {"A", "B"})
        self.assertTrue(all(r["n_outliers"] == 0 for r in result["outliers_per_group"].values()))

    def test_comprehensive_reuses_groups_and_preserves_single_screen_results(self):
        # Non-default row labels, interleaved groups, missing values and an unused
        # categorical level expose lost group-local positions or missing counts.
        data = pd.DataFrame({
            "v": [0., 10., np.nan, 12., 0., np.nan, 0., 14., 0., 16., 20., 18.],
            "g": pd.Categorical(list("BABABABABABA"), categories=["A", "B", "unused"]),
        }, index=["r" + str(i) for i in range(12)])
        expected_outliers = {
            label: checks.detect_outliers(frame["v"], name=str(label), plot=False)
            for label, frame in data.groupby("g", sort=False, observed=True)
        }
        expected_normality = checks.check_normality_per_group(data, "v", "g", plot=False)
        expected_homogeneity = checks.check_homogeneity_of_variance(data, "v", "g", plot=False)
        with mock.patch.object(checks, "_groups", wraps=checks._groups) as prepare:
            with contextlib.redirect_stdout(io.StringIO()):
                result = checks.comprehensive_assumption_check(data, "v", "g", plot=False)
        self.assertEqual(prepare.call_count, 1, "comprehensive diagnostics should prepare each group once")
        self.assertEqual(list(result["outliers_per_group"]), ["B", "A"])
        pd.testing.assert_frame_equal(result["normality_per_group"], expected_normality)
        for label, expected in expected_outliers.items():
            actual = result["outliers_per_group"][label]
            self.assertEqual(set(actual), set(expected))
            for key in expected:
                if isinstance(expected[key], np.ndarray):
                    np.testing.assert_array_equal(actual[key], expected[key])
                else:
                    self.assertEqual(actual[key], expected[key])
        actual = result["homogeneity"]
        self.assertEqual(set(actual), set(expected_homogeneity))
        for key, expected in expected_homogeneity.items():
            if isinstance(expected, np.ndarray):
                np.testing.assert_array_equal(actual[key], expected)
            else:
                self.assertEqual(actual[key], expected)
        outliers = result["outliers_per_group"]["B"]
        self.assertEqual(outliers["n_missing"], 1)
        np.testing.assert_array_equal(outliers["outlier_indices"], [5])
        np.testing.assert_array_equal(outliers["outlier_labels"], ["r10"])
        self.assertEqual(result["homogeneity"]["n_missing"], 2)

    def test_ols_diagnostics_keep_design_guards_and_order_opt_in(self):
        from statsmodels.regression.linear_model import OLS
        from statsmodels.tools.tools import add_constant

        x = np.arange(30, dtype=float)
        y = 2 + 0.3 * x + np.random.default_rng(9).normal(size=30)
        model = OLS(y, add_constant(x)).fit()
        result = checks.check_regression_diagnostics(model, plot=False)
        self.assertIsNone(result["autocorrelation"]["statistic"])
        ordered = checks.check_regression_diagnostics(model, plot=False, ordered=True)
        self.assertTrue(np.isfinite(ordered["autocorrelation"]["statistic"]))
        with warnings.catch_warnings():
            warnings.filterwarnings("ignore", message="The design matrix is rank-deficient.*")
            invalid_models = (
                OLS(y, x).fit(),
                OLS(y, np.column_stack([np.ones(30), x, x])).fit(),
                OLS(2 + 0.3 * x, add_constant(x)).fit(),
            )
        for invalid in invalid_models:
            with self.subTest(model=invalid), self.assertRaises(ValueError):
                checks.check_regression_diagnostics(invalid, plot=False)


if __name__ == "__main__":
    unittest.main()
