# 诊断：数值筛查与设计审查分别负责

先核对待估量、采样单位、配对/层级、缺失政策和实际执行，再选择相关诊断。
图形与数值筛查用于发现具体问题，不签发“所有假设成立”结论，也不按 p 值自动换方法。

## 需要检查什么

| 内容 | 怎样检查 | 解释边界 |
| --- | --- | --- |
| 独立/相关结构 | 采集流程、ID、设备/受试者/录音/批次、时间顺序 | Shapiro、Levene、Durbin–Watson 都不能证明独立 |
| 分布与尾部 | 按问题看组内数据、配对差值或回归残差；Q–Q、原始点与尾部 | 没有通用 n=30 门槛；小样本检验不显著也可能信息不足 |
| 方差结构 | 组内尺度、残差对拟合值；适当的 Levene/Breusch–Pagan | 不用方差预检验在 pooled/Welch 间选显著结果 |
| 均值/链接函数 | 残差形态、设计知识、适当非线性项和模型比较 | Pearson r 大不证明线性，残差图也不能完成因果识别 |
| 识别、影响与精度 | 设计矩阵秩、参数不确定性、VIF、杠杆与影响点 | VIF/影响阈值仅是线索，不自动删协变量或观测 |
| 缺失、异常与数据来源 | 追溯原始位置、测量/录入原因、排除规则与敏感性 | 不同处理方式对应不同假设；不要默默丢行或删有效极端值 |

配对 t 检查对齐差值；回归检查相关残差结构，不要求预测变量/结果边际正态。
常规小样本 t/F 推断的正态误差假设与系数估计所需条件不同。OLS 拟合残差是相关投影，残差 Shapiro 仅作筛查。
秩、置换与 bootstrap 各有目标和条件；对错误采样单位增加重采样次数不能修复设计。

## 现有辅助脚本

将本技能 `scripts/` 加入 `sys.path` 或 `PYTHONPATH` 后：

```python
from assumption_checks import (
    check_normality, check_normality_per_group,
    check_homogeneity_of_variance, check_linearity, detect_outliers,
    check_regression_diagnostics, comprehensive_assumption_check,
)

# 独立组描述性筛查；小任务也可只调用相关的单项函数
screens = comprehensive_assumption_check(df, "score", "group", plot=False)
```

`plot=True` 是兼容默认值；`plot=False` 不导入 `matplotlib.pyplot`。
NaN 省略数量在结果中返回；Inf、非一维/复数/掩码、样本不足及不支持诊断的退化数据会拒绝。
分组标签缺失会拒绝；未使用分类水平忽略。分组异常点为 `outliers_per_group`，索引为组内输入原位置并保留 Series 标签。
`check_linearity` 对 x/y 共同删除缺失行，保持位置配对；调用者仍需先对齐受试者/记录 ID。
`is_normal`/`is_homogeneous`、`Normal=Yes` 仅为旧兼容字段，表示未拒绝。
Shapiro n>5000 返回 `p_value_reliable=False`，二元判断为 `None`；其 p 值不用于该判断。

## OLS 诊断

```python
import statsmodels.api as sm
from assumption_checks import check_regression_diagnostics

model = sm.OLS(y, sm.add_constant(X)).fit()
diag = check_regression_diagnostics(model, plot=False)
# 仅当行确有时间/空间等有意义顺序时再传 ordered=True
# 独立误差且已决定使用异方差稳健推断时：
robust = model.get_robustcov_results(cov_type="HC3")
```

辅助函数只接受带显式非零截距、至少一个预测变量、满秩、正残差自由度且非近乎完美拟合的 OLS。
返回残差 Shapiro、Koenker Breusch–Pagan（`robust=True`）、VIF；`ordered=True` 才计算 Durbin–Watson，无通用通过阈值。
HC3 不修复聚类、遗漏混杂、错误均值模型或因果识别；依赖数据使用设计匹配的模型/推断。
GLM/logistic 不使用本 OLS 辅助函数：另外检查分离、收敛、校准、过度离散和适当影响诊断。
重复测量 ANOVA 需要匹配完整/缺失结构与球形性处理；缺失/不等访视不应靠独立检验补救。

## 交付

给出实际检查、发现与处理，尚未检查的设计/模型条件，以及对结论和敏感性分析的影响。只生成有助于判断的诊断图。

实现边界参考：[SciPy Shapiro](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.shapiro.html)、
[Levene](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.levene.html)、
[Breusch–Pagan](https://www.statsmodels.org/stable/generated/statsmodels.stats.diagnostic.het_breuschpagan.html)。
