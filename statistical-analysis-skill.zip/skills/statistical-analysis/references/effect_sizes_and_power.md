# 效应、不确定性与研究规模

优先报告问题直接关心的效应及区间，如均值差、回归斜率、风险差/比与预测误差。
标准化量用于适当的比较，但不能替代原单位、具体条件和有意义差异。

## 效应量边界

| 量 | 使用时说明 |
| --- | --- |
| Cohen d / Hedges g | 分母定义、方向与独立/配对设计；g 修正小样本偏差，不修复设计错误 |
| 配对 d_z / d_av | 分别基于差值 SD / 两次测量尺度，不能交换名称与区间公式 |
| eta² / partial eta² / omega² | 不是同一量；单因素设计的 eta² 与 partial eta² 可重合，多因素下不可泛化 |
| Cohen f / f² | 分别匹配 ANOVA / 回归功效问题；不要把 f 与 f² 或 eta² 混用 |
| r / rho / R² | 相关、解释比例和标准化回归系数是不同量；条件于模型和变量编码 |
| OR / RR / 风险差 | 明确事件、参照组、随访与表格方向；OR 通常不能直接解释为 RR |
| 秩效应量、ICC 等 | 写明具体定义、方向与模型；不统一套用 d 的大小阈值 |

常用 small/medium/large 阈值是惯例，不是学科通用的实际重要性判据。
若使用 Pingouin，检查已装版本实际列名；`ttest` 的 d 可能为绝对值，方向应由原始对比或显式计算确定。
`compute_effsize_from_t` 仅给点估计；pooled-d 的近似区间不应直接用于异方差或配对 d_av。

## 区间与重采样

Welch t 的区间是均值差区间，不是 d 的区间。配对分析共同处理两次测量的缺失，报告实际分析 n。
选择与采样设计一致的方法：按独立单位 bootstrap，配对量保持配对，聚类/时序保持相应相关结构。

```python
import numpy as np
from scipy import stats

# a、b 为已按声明政策处理的有限独立观测；示例目标为 a-b 的均值差
estimate = np.mean(a) - np.mean(b)
interval = stats.bootstrap(
    (a, b), lambda x, y: np.mean(x) - np.mean(y),
    vectorized=False, paired=False, confidence_level=0.95,
    n_resamples=9999, method="BCa", rng=np.random.default_rng(42),
).confidence_interval
```

BCa 在退化/离散小样本中可能未定义；检查警告、有限端点和 Monte Carlo 稳定性。
上例不适用于把同一录音的时窗当独立观测，也不代替配对/聚类 bootstrap。

## 研究规模：目标效应、精度或资源

研究设计可依据预先指定的有意义效应与功效、目标区间宽度、可获得总体或资源限制；记录选择及影响。
明确方差、比例、组数/分配比、独立单位数、重复相关、失访和多重比较；不要直接把先导研究最大效应当保证。
闭式模型不匹配时，对实际计划的设计与估计过程做模拟并检查假阳性、偏差、覆盖率和精度。

```python
import math
from statsmodels.stats.power import tt_ind_solve_power, FTestAnovaPower

# 独立、共同方差、等组规划模型；d=.5 是示例，须换成有依据的目标
n_group = math.ceil(tt_ind_solve_power(
    effect_size=0.5, alpha=0.05, power=0.80, ratio=1, alternative="two-sided",
))

# 单因素平衡 ANOVA；参数为 k_groups，返回总样本量
n_total = FTestAnovaPower().solve_power(
    effect_size=0.25, k_groups=3, alpha=0.05, power=0.80,
)
n_anova_group = math.ceil(n_total / 3)  # 实施总量为 3*n_anova_group

# 固定 n 的敏感性：给定模型能以指定功效检测多大的效应
detectable_d = tt_ind_solve_power(
    effect_size=None, nobs1=50, alpha=0.05, power=0.80,
    ratio=1, alternative="two-sided",
)
```

独立共同方差规划不自动适用 Welch、聚类、配对、失访或其他待估量。
相关功效可按需用已装 Pingouin 的 `power_corr`；复杂重复/层级设计使用相应方法，不把重复次数当独立 n。
用观测效应计算的 observed power 不用于解释已经得到的显著/非显著结果；报告区间或有明示假设的敏感性。
序贯决策需要预先定义规则；不能边采边重复检验直到显著。

实现参考：[statsmodels power](https://www.statsmodels.org/stable/stats.html#power-and-sample-size-calculations)、
[SciPy bootstrap](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.bootstrap.html)、
[Pingouin effect sizes](https://pingouin-stats.org/generated/pingouin.compute_effsize.html)。
