# 方法选择：先确定问题与依赖结构

先明确待估量、观测单位、数据类型、预定对比和缺失政策，再选方法。
下表是候选路线；Shapiro/Levene 的 p 值不是自动切换开关。

## 常见路线

| 问题/设计 | 候选方法 | 关键边界 |
| --- | --- | --- |
| 两独立组均值差 | Welch t | pooled Student 需要有依据的共同方差；报告有方向的原单位均值差及区间 |
| 多独立组均值与预定对比 | Welch ANOVA；适当的对比/回归 | 异方差全组两两比较可用 Games–Howell；共同方差设计的全组两两比较可用 Tukey |
| 两次配对均值 | 配对 t | 按 ID 对齐，分析差值；不能分别删除两列缺失后重新配对 |
| 多次测量、设备/受试者/地点内相关 | 混合模型、GEE 或设计匹配的聚合/推断 | 明确层级、时间及相关结构；重复测量 ANOVA 还需考虑球形性/协方差假设 |
| 独立秩/分布差异 | Mann–Whitney、Kruskal–Wallis | 中位数/位置移位解释需要额外分布形状条件 |
| 配对秩/中位数差异 | signed-rank 或 sign test | signed-rank 需要差值大小有意义且分布对称；sign test 的目标不同 |
| 完整区组的多条件秩比较 | Friedman | 不完整/不等次数测量通常需要另外建模 |
| 线性/单调关联 | Pearson / Spearman / Kendall | 按问题选，非按边际正态性选；关联不自动支持因果解释 |
| 连续结果与多个变量 | 线性回归、必要的非线性项/GAM | 说明条件均值与误差结构；HC3 处理独立异方差，不处理聚类或混杂 |
| 二元/计数结果 | logistic / Poisson / negative binomial | 检查分离、过度离散、曝光量；很多零本身不证明需要零膨胀模型 |
| 分类计数/配对分类 | 列联表方法；McNemar / Cochran Q | 稀疏表考虑适合表形和设计的精确/重采样方法，不能只看总样本量 |
| 生存/删失数据 | log-rank / Cox / 参数生存模型 | 检查删失机制与比例风险等模型假设；不能当普通连续数据处理 |
| 一致性/可靠性 | Bland–Altman、适当 ICC、kappa 等 | 相关系数不等于一致性；ICC 报告模型、单次/平均和一致/绝对一致定义 |

多因素/协变量设计：预先明确主效应、交互和对比；不平衡设计中报告编码、基准水平与平方和/检验定义。
随机分配不消除重复测量、聚类、失访或测量偏差；观察性回归/匹配也不自动完成因果识别。

## 用成熟库直接执行

以下数组均应已按声明的缺失政策处理，包含有限值和正确的独立/配对单位。

```python
from scipy import stats

# 独立均值；显式选 Welch，区间对应 a-b 的原单位均值差
welch = stats.ttest_ind(a, b, equal_var=False, nan_policy="raise")
mean_difference_ci = welch.confidence_interval(confidence_level=0.95)

# 配对 ID 和缺失行已共同对齐；差值方向仍为 before-after
paired = stats.ttest_rel(before, after, nan_policy="raise")

# 多组异方差均值的整体检验
from statsmodels.stats.oneway import anova_oneway
omnibus = anova_oneway((a, b, c), use_var="unequal")
```

整体检验、预定对比与探索性两两比较是不同问题；事先定义检验族与区间/校正方案。
Holm 可控制检验族错误率；Benjamini–Hochberg 针对声明检验族的 FDR，适用条件与解释不同。可直接使用 `statsmodels.stats.multitest.multipletests(p_values, method="holm")`；不能按结果显著多少选择校正。
Pingouin 可按需用于 Games–Howell 等常用实现；实际列名和参数按已装版本确认，不照搬旧输出。
小样本、并列值与离散数据的精确/置换方案需要适当的交换性与采样单位；默认 `auto` 不普遍代表精确检验。

## 无法从单一检验修复的问题

- 聚类/时序：按独立单位划分与重采样；独立样本 t 检验不适用于相关时窗。
- 缺失：说明完整案例、插补或似然法的假设；MCAR 常为充分条件，但并非所有完整案例估计都必须 MCAR。
- 预测：先定训练/验证/测试与调参范围；测试集反复选模型会污染最终评价。
- 无效应主张：非显著不支持等效。等效界值要有科学依据；Bayes factor 也依赖明确的先验与比较模型。
- 纯确定性数值计算：回到误差、稳定性、收敛和基准验证，而非为了论文形式添加统计检验。

## 实现参考

[SciPy ttest_ind](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.ttest_ind.html)、
[Mann–Whitney](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.mannwhitneyu.html)、
[Wilcoxon](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.wilcoxon.html)、
[statsmodels one-way](https://www.statsmodels.org/stable/generated/statsmodels.stats.oneway.anova_oneway.html)。
生存、精确 logistic、GEE/混合模型与缺失处理在此仅作方法路线，不代表已完成实现或验证。
