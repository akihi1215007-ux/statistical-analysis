# 贝叶斯分析：仅在问题需要时进入

适用于需要整合先验、估计后验概率/区间、层级模型或明确模型比较的任务。
不用贝叶斯或 MCMC 作为小样本、非显著或“更高级”的默认替代方案；先判断目标和可用实现。

## 建模与解释

- **目标**：写明待估量、实际单位、决策问题及独立/配对/层级结构。
- **似然**：匹配数据生成、删失、缺失、测量与相关结构；共享方差正态模型不是 Welch 模型。
- **先验**：说明来源、尺度和支持范围；在结果实际单位上检查先验预测，必要时评估合理先验范围的敏感性。
- **后验**：区分点/区间估计、方向概率、实际等效区间和预测；可信区间解释依赖给定模型与先验。
- **模型比较**：Bayes factor 是两个指定模型的边际似然比；后验方向概率、可信区间不跨零、预测分数都不自动构成 point-null BF。

不把惯用 BF 档位直接等同科学结论。针对点零的比较需明确零/备择模型、参数先验与可用计算方法；任意先验可能显著影响证据比。
“统计上足够接近零”需要有科学依据的等效范围，不能在看到结果后扩大范围。

## 优先简单、适配的计算

共轭模型可直接用成熟分布计算，不必引入采样器。例如独立 Bernoulli 成功率、无选择偏差/聚类的 Beta–Binomial 模型：

```python
from scipy import stats

# successes 和 n 为已核验的整数计数，0 <= successes <= n
# a0,b0 是预先选择、需说明依据的正先验参数
a_post = a0 + successes
b_post = b0 + n - successes
interval = stats.beta.ppf([0.025, 0.975], a_post, b_post)
prob_above_target = stats.beta.sf(target_rate, a_post, b_post)
```

该例估计概率，不是因果效应或点零 BF；相关重复试验或异质成功率可能需要其他模型。
若任务确需 PyMC/ArviZ，先检查项目现有依赖和 API，不自动安装或指定固定版本。数据容器、HDI/summary 参数和绘图 API 随版本不同，以实际签名为准。

## 需要采样时才做相应诊断

检查多链混合、有限的 R-hat/ESS/MCSE、发散、能量/树深问题及后验预测。
R-hat 接近 1、足够的有效样本量和较小 Monte Carlo 误差是诊断线索，不能单独证明模型正确；阈值结合待报告量与精度要求。
短合成数据 smoke test 仅证明 API 能执行，不证明正式模型收敛。先验/后验预测检查回答模型是否产生合理数据；不能只看采样退出码。
顺序收集仍要说明模型、损失/决策、检查时点和停止规则，不声称贝叶斯方法普遍消除可选停止问题。

## 报告

说明似然、先验及单位、数据层级、计算方法、实际依赖版本、后验摘要/区间定义与概率、采样诊断（如使用）、预测检查和敏感性。
实际未运行或诊断未完成时直接标明；把模型假设与科学解释边界一并交下游。

实现参考：[SciPy beta](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.beta.html)、
[PyMC documentation](https://www.pymc.io/projects/docs/en/stable/)、
[ArviZ documentation](https://python.arviz.org/en/stable/)。
