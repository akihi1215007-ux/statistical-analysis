"""Exercise the installed bundle away from the repository and original source."""

import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest


SKILL = Path(__file__).resolve().parents[1] / "skills" / "statistical-analysis"


class InstallationTests(unittest.TestCase):
    def test_copied_skill_runs_its_behavioral_suite_in_isolation(self):
        self.assertTrue(SKILL.is_dir(), "Installable skill directory is missing")
        with tempfile.TemporaryDirectory(prefix="statistical-skill-") as temporary:
            installed = Path(temporary) / "skills" / "statistical-analysis"
            shutil.copytree(SKILL, installed)
            env = dict(os.environ, PYTHONUTF8="1", PYTHONDONTWRITEBYTECODE="1",
                       PYTHONPATH=str(installed / "scripts"), MPLBACKEND="Agg")
            result = subprocess.run(
                [sys.executable, "-B", "-m", "unittest", "discover", "-s", "tests", "-v"],
                cwd=installed, env=env, capture_output=True, text=True,
                encoding="utf-8", timeout=120,
            )
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)


if __name__ == "__main__":
    unittest.main()
